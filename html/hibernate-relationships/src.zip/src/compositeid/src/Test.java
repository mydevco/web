import cirrus.hibernate.*;
import java.util.*;

public class Test
{
    public static void main(String[] args) throws Exception
    {
        try
        {
            // Initialise
            Datastore dataStore = Hibernate.createDatastore().storeFile("Schema.hbm.xml");
            SessionFactory sessionFactory = dataStore.buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction t = session.beginTransaction();
            System.out.println("KEY-MANY-TO-ONE (2) MAPPING");

            Address addr = new Address();
            addr.setId(1);
            session.save(addr);

            Foo foo = new Foo();
            Person person = new Person();
            person.setName("Brian");
            person.setAddress(addr);
            foo.setId(person);
            foo.setAge("24");
            session.save(foo);
            t.commit();
            session.close();

            // Re-load
            session = sessionFactory.openSession();
            t = session.beginTransaction();
            foo = (Foo)session.load(Foo.class, person);
            System.out.println("Foo: " + foo.getId() + ", age = " + foo.getAge());

            t.commit();
            session.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }
    }
}
