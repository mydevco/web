import java.util.*;

public class Foo
{
    protected Person id;
    protected String age;

    public Foo()
    {
    }

    public Person getId()
    {
        return id;
    }

    public void setId(Person id)
    {
        this.id = id;
    }

    public String getAge()
    {
        return age;
    }

    public void setAge(String age)
    {
        this.age = age;
    }

}
