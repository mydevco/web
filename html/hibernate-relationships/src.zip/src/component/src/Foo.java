public class Foo
{
    protected int id;
    protected FooSecond second;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public FooSecond getSecond()
    {
        return second;
    }

    public void setSecond(FooSecond second)
    {
        this.second = second;
    }
}
