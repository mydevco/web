import java.util.*;

public class Foo
{
    protected int id;
    protected Set names;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Set getNames()
    {
        return names;
    }

    public void setNames(Set names)
    {
        this.names = names;
    }
}
