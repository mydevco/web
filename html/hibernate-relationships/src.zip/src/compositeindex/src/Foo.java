import java.util.*;

public class Foo
{
    protected int id;
    protected Map map;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Map getAges()
    {
        return map;
    }

    public void setAges(Map map)
    {
        this.map = map;
    }
}
