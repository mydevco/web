import cirrus.hibernate.*;
import java.util.*;

public class Test
{
    public static void main(String[] args) throws Exception
    {
        try
        {
            // Initialise
            Datastore dataStore = Hibernate.createDatastore().storeFile("Schema.hbm.xml");
            SessionFactory sessionFactory = dataStore.buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction t = session.beginTransaction();
            System.out.println("KEY-MANY-TO-ONE MAPPING");

            // Foo and Bar
            Foo foo = new Foo();
            foo.setId(1);
            Map map = new HashMap();

            addPerson("Brian", "24", session, map, 1);
            addPerson("Paula", "51", session, map, 2);
            addPerson("Tony", "33", session, map, 3);
            addPerson("Murphy", "18", session, map, 4);
            foo.setAges(map);
            session.save(foo);
            t.commit();
            session.close();

            // Re-load
            session = sessionFactory.openSession();
            t = session.beginTransaction();
            foo = (Foo)session.load(Foo.class, new Integer(1));
            System.out.println("Foo: " + foo.getId() + ", " + foo.getAges());

            t.commit();
            session.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }
    }

    protected static void addPerson(String name, String age, Session session, Map map, int id) throws Exception
    {
        Address addr = new Address();
        addr.setId(id);
        session.save(addr);
        Person person = new Person();
        person.setName(name);
        person.setAddress(addr);
        map.put(person, "24");
    }
}
