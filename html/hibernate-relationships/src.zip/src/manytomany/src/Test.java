import cirrus.hibernate.*;
import java.util.*;

public class Test
{
    public static void main(String[] args) throws Exception
    {
        // Initialise
        Datastore dataStore = Hibernate.createDatastore().storeFile("Schema.hbm.xml");
        SessionFactory sessionFactory = dataStore.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction t = session.beginTransaction();
        System.out.println("MANY-TO-MANY MAPPING");

        // Foo and Bar
        Set set = new HashSet();
        Bar bar = new Bar();
        bar.setId(1);
        session.save(bar);
        set.add(bar);
        bar = new Bar();
        bar.setId(2);
        session.save(bar);
        set.add(bar);

        Foo foo = new Foo();
        foo.setId(1);
        foo.setBars(set);
        session.save(foo);
        t.commit();
        session.close();

        // Re-load
        session = sessionFactory.openSession();
        t = session.beginTransaction();
        foo = (Foo)session.load(Foo.class, new Integer(1));
        System.out.println("Foo: " + foo.getId() + ", " + foo.getBars());

        bar = (Bar)session.load(Bar.class, new Integer(2));
        System.out.println("Bar: " + bar.getId());

        t.commit();
        session.close();
    }
}
