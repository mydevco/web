import java.util.*;

public class Foo
{
    protected int id;
    protected Set bars;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Set getBars()
    {
        return bars;
    }

    public void setBars(Set bars)
    {
        this.bars = bars;
    }
}
