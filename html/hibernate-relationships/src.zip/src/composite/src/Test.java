import cirrus.hibernate.*;
import java.util.*;

public class Test
{
    public static void main(String[] args) throws Exception
    {
        // Initialise
        Datastore dataStore = Hibernate.createDatastore().storeFile("Schema.hbm.xml");
        SessionFactory sessionFactory = dataStore.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction t = session.beginTransaction();
        System.out.println("COMPOSITE MAPPING");

        // Foo
        Foo foo = new Foo();
        foo.setId(1);
        Set set = new HashSet();
        FooSecond second = new FooSecond();
        second.setFirstName("Joe");
        second.setLastName("Bloggs");
        set.add(second);
        second = new FooSecond();
        second.setFirstName("John");
        second.setLastName("Smith");
        set.add(second);
        foo.setSeconds(set);
        session.save(foo);
        t.commit();
        session.close();

        // Re-load
        session = sessionFactory.openSession();
        t = session.beginTransaction();
        foo = (Foo)session.load(Foo.class, new Integer(1));
        System.out.println("Foo: " + foo.getId() + ", " + foo.getSeconds());

        t.commit();
        session.close();
    }
}
