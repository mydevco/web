import java.util.*;

public class Foo
{
    protected int id;
    protected Set seconds;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Set getSeconds()
    {
        return seconds;
    }

    public void setSeconds(Set seconds)
    {
        this.seconds = seconds;
    }
}
