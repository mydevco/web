public class FooSecond
{
    protected String firstName;
    protected String lastName;

    public FooSecond()
    {
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String toString()
    {
        return "(" + firstName + ", " + lastName + ")";
    }
}