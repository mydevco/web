public class Bar extends Foo
{
    protected String age;

    public Bar()
    {
    }

    public String getAge()
    {
        return age;
    }

    public void setAge(String age)
    {
        this.age = age;
    }
}

