import java.util.*;

public class Foo
{
    protected int id;
    protected Set set;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Set getBarSnafus()
    {
        return set;
    }

    public void setBarSnafus(Set set)
    {
        this.set = set;
    }
}
