public class BarSnafu
{
    protected Bar bar;
    protected Snafu snafu;

    public BarSnafu()
    {
    }

    public Snafu getSnafu()
    {
        return snafu;
    }

    public void setSnafu(Snafu snafu)
    {
        this.snafu = snafu;
    }

    public Bar getBar()
    {
        return bar;
    }

    public void setBar(Bar bar)
    {
        this.bar = bar;
    }

    public String toString()
    {
        return bar.getId() + ", " + snafu.getId();
    }
}
