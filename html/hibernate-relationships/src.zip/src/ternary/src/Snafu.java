public class Snafu
{
    protected int id;

    public Snafu()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }
}