import java.util.*;

public class Foo
{
    protected int id;
    protected Set people;

    public Foo()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Set getPeople()
    {
        return people;
    }

    public void setPeople(Set people)
    {
        this.people = people;
    }
}
