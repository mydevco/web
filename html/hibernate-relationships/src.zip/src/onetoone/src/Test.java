import cirrus.hibernate.*;
import java.sql.*;

public class Test
{
    public static void main(String[] args) throws Exception
    {
        try
        {
            // Initialise
            Datastore dataStore = Hibernate.createDatastore().storeFile("Schema.hbm.xml");
            SessionFactory sessionFactory = dataStore.buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction t = session.beginTransaction();
            System.out.println("ONE-TO-ONE MAPPING");

            // Foo and Bar
            Foo foo = new Foo();
            foo.setId(1);
            session.save(foo);
            Bar bar = new Bar();
            bar.setId(1);
            session.save(bar);
            t.commit();
            session.close();

            // Re-load
            session = sessionFactory.openSession();
            t = session.beginTransaction();
            foo = (Foo)session.load(Foo.class, new Integer(1));
            System.out.println("Foo: " + foo.getId() + ", " + foo.getBar());
            bar = (Bar)session.load(Bar.class, new Integer(1));
            System.out.println("Bar: " + bar.getId());

            t.commit();
            session.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }
    }
}
